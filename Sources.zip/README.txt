Distribuci�n de "Willy en el desierto" 
======================================
Pr�cticas de Sistemas Inteligentes (Grado en Ingenier�a Inform�tica, UCO)
Por: Carlos Garc�a Mart�nez, Manuel Jes�s Mar�n Jim�nez y Amelia Zafra G�mez


Quick start:
------------
 - Copia el contenido del directorio correspondiente a tu sistema operativo en el mismo directorio donde se encuentre el fichero "WillyDemo.jar"
 - Escribe en el terminal: java -Djava.library.path=. -jar WillyDemo.jar
 - Pulsa el bot�n "All maps" para resolver todos los mapas existentes en el directorio "maps"
 
 